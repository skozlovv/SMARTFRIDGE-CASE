from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import func
from sqlalchemy import and_, ForeignKey
import base64
from datetime import datetime

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///products.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


db = SQLAlchemy(app)


# Модели DB
class Products(db.Model):
    __tablename__ = "products"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String)
    category = db.Column(db.String)
    date_man = db.Column(db.Integer)
    date_exp = db.Column(db.Integer)
    quantity = db.Column(db.Float)
    quantity_unit = db.Column(db.String)
    nutritional_values = db.Column(db.Float)
    nutritional_values_unit = db.Column(db.String)
    count = db.Column(db.Float)
    count_unit = db.Column(db.String)
    date_add = db.Column(db.DateTime, default=func.now())
    # Связь с другими таблицами
    fridge_items = db.relationship("Fridge", backref="product", lazy="dynamic")
    remote_items = db.relationship("Remote", backref="product", lazy="dynamic")
    added_items = db.relationship("Added", backref="product", lazy="dynamic")


class Fridge(db.Model):
    __tablename__ = "fridge"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, ForeignKey("products.id"), nullable=False)
    date_add = db.Column(db.DateTime, default=func.now())


class Remote(db.Model):
    __tablename__ = "remote"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, ForeignKey("products.id"), nullable=False)
    date_add = db.Column(db.DateTime, default=func.now())


class Added(db.Model):
    __tablename__ = "added"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, ForeignKey("products.id"), nullable=False)
    date_add = db.Column(db.DateTime, default=func.now())


@app.before_request
def create_tables():
    db.create_all()


@app.route("/")
def index():
    frige_list = Fridge.query.all()
    current_date = datetime.now().strftime("%d-%m-%Y")
    timestamp = datetime.strptime(current_date, "%d-%m-%Y").timestamp()
    if frige_list:
        return render_template("index.html", frige_list=frige_list, now=current_date)
    else:
        return render_template("index.html", frige_list=[], now=timestamp)


@app.route("/delete", methods=["POST"])
def delete_page():
    product_id = request.form.get("product_id")
    product_to_delete = Fridge.query.filter_by(product_id=product_id).first()
    if product_to_delete:
        new_product_del = Remote(
            product_id=product_id,
        )
        db.session.add(new_product_del)
        db.session.delete(product_to_delete)
        db.session.commit()
    return redirect(url_for("index"))


@app.route("/delete_info")
def delete_page_info():
    data_list = Remote.query.all()
    if data_list:
        return render_template("remove_page.html", data_list=data_list)
    else:
        return render_template("remove_page.html", data_list=[])


@app.route("/add", methods=["POST"])
def add_page():
    product_id = request.form.get("product_id")
    new_product_fridge = Fridge(
        product_id=product_id,
    )
    new_product_add = Added(
        product_id=product_id,
    )
    db.session.add(new_product_fridge)
    db.session.add(new_product_add)
    db.session.commit()
    return redirect(url_for("index"))


@app.route("/add_info")
def add_page_info():
    data_list = Added.query.all()
    if data_list:
        return render_template("add_page.html", data_list=data_list)
    else:
        return render_template("add_page.html", data_list=[])


@app.route("/fridge_list", methods=["GET"])
def fridge_list():
    return "<p>Список продуктов в холодильнике</p>"


@app.route("/qcode/<qdata>")
def qcode_page(qdata):
    decoded_bytes = base64.urlsafe_b64decode(qdata.encode("utf-8"))
    decoded_string = decoded_bytes.decode("utf-8")
    decoded_string_values = decoded_string.split(";")
    keys = [
        "name",
        "category",
        "date_man",
        "date_exp",
        "quantity",
        "quantity_unit",
        "nutritional_values",
        "nutritional_values_unit",
        "count",
        "count_unit",
    ]
    product_data = dict(zip(keys, decoded_string_values))

    existing_product = Products.query.filter(
        and_(
            Products.name == product_data["name"],
            Products.category == product_data["category"],
            Products.date_man == product_data["date_man"],
            Products.date_exp == product_data["date_exp"],
            Products.quantity == product_data["quantity"],
            Products.quantity_unit == product_data["quantity_unit"],
            Products.nutritional_values == product_data["nutritional_values"],
            Products.nutritional_values_unit == product_data["nutritional_values_unit"],
            Products.count == product_data["count"],
            Products.count_unit == product_data["count_unit"],
        )
    ).first()

    if not existing_product:
        new_product = Products(
            name=product_data["name"],
            category=product_data["category"],
            date_man=product_data["date_man"],
            date_exp=product_data["date_exp"],
            quantity=product_data["quantity"],
            quantity_unit=product_data["quantity_unit"],
            nutritional_values=product_data["nutritional_values"],
            nutritional_values_unit=product_data["nutritional_values_unit"],
            count=product_data["count"],
            count_unit=product_data["count_unit"],
        )
        db.session.add(new_product)
        db.session.commit()
        product_id = new_product.id
        print("добавили новый продукт", new_product.id)
    else:
        product_id = existing_product.id
        print("продукт в базе есть", existing_product.id)

    # Проверяем в холодильнике
    existing_product_fridge = Fridge.query.filter(
        Fridge.product_id == product_id
    ).first()
    if existing_product_fridge:
        existing_product_fridge = existing_product_fridge.product.id
        print("есть в холодильнике")
    else:
        print("нет в холодильнике")
    return render_template(
        "qcode_info.html",
        product_data=product_data,
        existing_product_fridge=existing_product_fridge,
        product_id=product_id,
    )


if __name__ == "__main__":
    app.run(debug=True)